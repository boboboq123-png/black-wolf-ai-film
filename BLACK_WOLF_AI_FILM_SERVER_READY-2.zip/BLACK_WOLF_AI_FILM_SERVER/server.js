import express from 'express';
import multer from 'multer';

const app = express();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }
});

app.use(express.static('public'));

function cleanBase64(dataUrl) {
  const comma = dataUrl.indexOf(',');
  return comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
}

app.post('/api/generate', upload.single('image'), async (req, res) => {
  try {
    const key = String(req.body.key || '').trim();
    const prompt = String(req.body.prompt || '').trim();
    const duration = String(req.body.duration || '5');
    const mode = String(req.body.mode || 'std');

    if (!key) return res.status(400).json({error:'ضع مفتاح Kling API أولاً.'});
    if (!req.file) return res.status(400).json({error:'اختر صورة أولاً.'});
    if (!prompt) return res.status(400).json({error:'اكتب وصف الفيديو أولاً.'});
    if (!['5','10'].includes(duration)) return res.status(400).json({error:'المدة يجب أن تكون 5 أو 10 ثوانٍ.'});

    const imageBase64 = req.file.buffer.toString('base64');
    const response = await fetch('https://api-singapore.klingai.com/v1/videos/image2video', {
      method:'POST',
      headers:{
        'Authorization':`Bearer ${key}`,
        'Content-Type':'application/json'
      },
      body:JSON.stringify({
        model_name:'kling-v3',
        image:imageBase64,
        prompt,
        duration,
        mode,
        sound:'off'
      })
    });

    const data = await response.json().catch(()=>({}));
    if (!response.ok || data.code !== 0) {
      return res.status(response.status || 502).json({error:data.message || `Kling API error (${response.status})`, details:data});
    }

    return res.json({taskId:data.data?.task_id, status:data.data?.task_status || 'submitted'});
  } catch (e) {
    return res.status(500).json({error:e.message || 'حدث خطأ في الخادم.'});
  }
});

app.get('/api/status/:taskId', async (req,res)=>{
  try {
    const key = String(req.query.key || '').trim();
    if (!key) return res.status(400).json({error:'مفتاح Kling مفقود.'});
    const id = encodeURIComponent(req.params.taskId);
    const response = await fetch(`https://api-singapore.klingai.com/v1/videos/image2video/${id}`, {
      headers:{'Authorization':`Bearer ${key}`}
    });
    const data = await response.json().catch(()=>({}));
    if (!response.ok || data.code !== 0) return res.status(response.status || 502).json({error:data.message || `Kling API error (${response.status})`, details:data});
    const d=data.data||{};
    const video=d.task_result?.videos?.[0]?.url || null;
    return res.json({status:d.task_status, message:d.task_status_msg || '', videoUrl:video});
  } catch(e) { return res.status(500).json({error:e.message || 'حدث خطأ في الخادم.'}); }
});

const port = process.env.PORT || 3000;
app.listen(port, ()=>console.log(`BLACK WOLF AI FILM running on http://localhost:${port}`));
